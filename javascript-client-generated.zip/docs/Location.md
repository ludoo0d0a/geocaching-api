# GeocachingApiV10.Location

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**country** | **String** |  | [optional] 
**countryId** | **Number** |  | [optional] 
**state** | **String** |  | [optional] 
**stateId** | **Number** |  | [optional] 


