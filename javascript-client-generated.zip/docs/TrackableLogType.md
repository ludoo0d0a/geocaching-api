# GeocachingApiV10.TrackableLogType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**name** | **String** |  | [optional] 
**imageUrl** | **String** |  | [optional] 


