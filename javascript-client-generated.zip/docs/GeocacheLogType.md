# GeocachingApiV10.GeocacheLogType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**name** | **String** |  | [optional] 
**imageUrl** | **String** |  | [optional] 


