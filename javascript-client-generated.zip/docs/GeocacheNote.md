# GeocachingApiV10.GeocacheNote

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**note** | **String** |  | 


