# GeocachingApiV10.GeocacheLimit

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**liteCallsRemaining** | **Number** |  | [optional] 
**liteCallsSecondsToLive** | **Number** |  | [optional] 
**fullCallsRemaining** | **Number** |  | [optional] 
**fullCallsSecondsToLive** | **Number** |  | [optional] 


