# GeocachingApiV10.Image

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **String** |  | [optional] 
**thumbnailUrl** | **String** |  | [optional] 
**largeUrl** | **String** |  | [optional] 
**referenceCode** | **String** |  | [optional] 
**createdDate** | **Date** |  | [optional] 
**description** | **String** | Description of the image | [optional] 
**guid** | **String** |  | [optional] 


