# GeocachingApiV10.AdditionalWaypoint

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**referenceCode** | **String** |  | [optional] 
**name** | **String** |  | [optional] 
**coordinates** | [**Coordinates**](Coordinates.md) |  | [optional] 
**description** | **String** |  | [optional] 
**typeId** | **Number** |  | [optional] 
**typeName** | **String** |  | [optional] 
**prefix** | **String** |  | [optional] 
**url** | **String** |  | [optional] 


