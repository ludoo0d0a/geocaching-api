# GeocachingApiV10.TrackableCount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**trackableType** | [**TrackableType**](TrackableType.md) |  | [optional] 
**count** | **Number** |  | [optional] 


