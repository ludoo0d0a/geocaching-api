# GeocachingApiV10.BulkFailure

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**referenceCode** | **String** |  | [optional] 
**message** | **String** |  | [optional] 
**statusCode** | **Number** |  | [optional] 


