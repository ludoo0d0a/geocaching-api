# ApiV10.PostGeocacheList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Name of the list | 
**description** | **String** | Description of the list | [optional] 
**typeId** | **Number** | List Type | [optional] 
**isPublic** | **Boolean** |  | [optional] 
**isShared** | **Boolean** |  | [optional] 


