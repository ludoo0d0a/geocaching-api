# ApiV10.UserWaypoint

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**referenceCode** | **String** |  | [optional] 
**description** | **String** |  | [optional] 
**isCorrectedCoordinates** | **Boolean** |  | 
**coordinates** | [**Coordinates**](Coordinates.md) |  | 
**geocacheCode** | **String** |  | 


