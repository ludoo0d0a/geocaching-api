# ApiV10.LogDraft

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**referenceCode** | **String** |  | [optional] 
**imageCount** | **Number** |  | [optional] 
**guid** | **String** |  | [optional] 
**geocacheCode** | **String** |  | [optional] 
**logType** | **String** |  | [optional] 
**geocacheLogType** | [**GeocacheLogType**](GeocacheLogType.md) |  | [optional] 
**note** | **String** |  | [optional] 
**loggedDateUtc** | **Date** |  | [optional] 
**loggedDate** | **Date** |  | [optional] 
**useFavoritePoint** | **Boolean** |  | [optional] 
**geocacheName** | **String** |  | [optional] 


