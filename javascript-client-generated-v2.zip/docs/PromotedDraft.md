# ApiV10.PromotedDraft

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**geocacheLog** | [**GeocacheLog**](GeocacheLog.md) |  | [optional] 
**successfulImages** | [**[Image]**](Image.md) |  | [optional] 
**failedImages** | [**[Image]**](Image.md) |  | [optional] 
**favoritePointApplied** | **Boolean** |  | [optional] 
**draftDeleted** | **Boolean** |  | [optional] 


