# ApiV10.BulkResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**successes** | **[String]** |  | [optional] 
**failures** | [**[BulkFailure]**](BulkFailure.md) |  | [optional] 


