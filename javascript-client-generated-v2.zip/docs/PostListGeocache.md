# ApiV10.PostListGeocache

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**referenceCode** | **String** |  | [optional] 
**name** | **String** |  | [optional] 


