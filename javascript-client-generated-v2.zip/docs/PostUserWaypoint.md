# ApiV10.PostUserWaypoint

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **String** |  | [optional] 
**isCorrectedCoordinates** | **Boolean** |  | 
**coordinates** | [**Coordinates**](Coordinates.md) |  | 
**geocacheCode** | **String** |  | 


