# ApiV10.PostImage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**base64ImageData** | **String** |  | 
**description** | **String** | Description of the image | [optional] 
**guid** | **String** |  | [optional] 


