# ApiV10.Souvenir

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**imagePath** | **String** |  | [optional] 
**thumbImagePath** | **String** |  | [optional] 
**title** | **String** |  | [optional] 
**description** | **String** |  | [optional] 
**foundDateUtc** | **Date** |  | [optional] 
**url** | **String** |  | [optional] 


