# ApiV10.UserData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**foundDate** | **Date** | The date the user found the Geocache | [optional] 
**dnfDate** | **Date** |  | [optional] 
**correctedCoordinates** | [**Coordinates**](Coordinates.md) |  | [optional] 
**isFavorited** | **Boolean** |  | [optional] 
**note** | **String** |  | [optional] 


