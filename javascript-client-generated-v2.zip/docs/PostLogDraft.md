# ApiV10.PostLogDraft

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**guid** | **String** |  | [optional] 
**geocacheCode** | **String** |  | 
**logType** | **String** |  | [optional] 
**geocacheLogType** | [**GeocacheLogType**](GeocacheLogType.md) |  | [optional] 
**note** | **String** |  | [optional] 
**loggedDateUtc** | **Date** |  | [optional] 
**loggedDate** | **Date** |  | [optional] 
**useFavoritePoint** | **Boolean** |  | [optional] 


