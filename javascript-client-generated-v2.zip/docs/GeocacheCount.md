# ApiV10.GeocacheCount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**geocacheType** | [**GeocacheType**](GeocacheType.md) |  | [optional] 
**count** | **Number** |  | [optional] 


