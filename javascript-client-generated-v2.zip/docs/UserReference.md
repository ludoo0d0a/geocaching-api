# ApiV10.UserReference

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**referenceCode** | **String** |  | [optional] 
**username** | **String** |  | [optional] 
**avatarUrl** | **String** |  | [optional] 


