# ApiV10.AttributeType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**name** | **String** |  | [optional] 
**hasYesOption** | **Boolean** |  | [optional] 
**hasNoOption** | **Boolean** |  | [optional] 
**yesIconUrl** | **String** |  | [optional] 
**noIconUrl** | **String** |  | [optional] 
**notChosenIconUrl** | **String** |  | [optional] 


