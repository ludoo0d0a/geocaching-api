# ApiV10.PostGeocacheLog

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**loggedDate** | **Date** |  | 
**text** | **String** |  | 
**type** | **String** |  | [optional] 
**geocacheLogType** | [**GeocacheLogType**](GeocacheLogType.md) |  | [optional] 
**updatedCoordinates** | [**Coordinates**](Coordinates.md) |  | [optional] 
**geocacheCode** | **String** |  | 
**usedFavoritePoint** | **Boolean** |  | [optional] 


