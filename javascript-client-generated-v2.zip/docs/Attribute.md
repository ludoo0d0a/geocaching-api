# ApiV10.Attribute

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**name** | **String** |  | [optional] 
**imageUrl** | **String** |  | [optional] 
**isOn** | **Boolean** |  | [optional] 


